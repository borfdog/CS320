package service;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testValidTask() {
        Task t = new Task("100", "Get Gas", "Fill up the tank before work");
        assertEquals("100", t.getTaskId());
        assertEquals("Get Gas", t.getName());
        assertEquals("Fill up the tank before work", t.getDescription());
    }

    @Test
    void testIdNull() {
        assertThrows(IllegalArgumentException.class,
            () -> new Task(null, "Get Gas", "Fill up the tank before work"));
    }

    @Test
    void testIdTooLong() {
        assertThrows(IllegalArgumentException.class,
            () -> new Task("12345678901", "Get Gas", "Fill up the tank before work"));
    }

    @Test
    void testNameNull() {
        assertThrows(IllegalArgumentException.class,
            () -> new Task("100", null, "Fill up the tank before work"));
    }

    @Test
    void testNameTooLong() {
        assertThrows(IllegalArgumentException.class,
            () -> new Task("100", "This task name is way too long", "Fill up the tank before work"));
    }

    @Test
    void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class,
            () -> new Task("100", "Get Gas", null));
    }

    @Test
    void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class,
            () -> new Task("100", "Get Gas",
                "This description is much too long because it goes past fifty characters"));
    }

    @Test
    void testSetters() {
        Task t = new Task("100", "Get Gas", "Fill up the tank before work");
        t.setName("Mow Lawn");
        t.setDescription("Mow the front and back yard");
        assertEquals("Mow Lawn", t.getName());
        assertEquals("Mow the front and back yard", t.getDescription());
    }

    @Test
    void testSettersRejectBadValues() {
        Task t = new Task("100", "Get Gas", "Fill up the tank before work");
        assertThrows(IllegalArgumentException.class, () -> t.setName(null));
        assertThrows(IllegalArgumentException.class, () -> t.setName("This task name is way too long"));
        assertThrows(IllegalArgumentException.class, () -> t.setDescription(null));
        assertThrows(IllegalArgumentException.class,
            () -> t.setDescription("This description is much too long because it goes past fifty characters"));
    }
}