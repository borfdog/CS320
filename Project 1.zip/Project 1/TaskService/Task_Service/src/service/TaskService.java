package service;
import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task is null");
        }
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("ID already exists");
        }
        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task not found");
        }
        tasks.remove(taskId);
    }

    public void updateName(String taskId, String name) {
        getExisting(taskId).setName(name);
    }

    public void updateDescription(String taskId, String description) {
        getExisting(taskId).setDescription(description);
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    private Task getExisting(String taskId) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found");
        }
        return task;
    }
}