package service;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService();
        service.addTask(new Task("100", "Wash Car", "Fill up the tank before work"));
    }

    @Test
    void testAddTask() {
        service.addTask(new Task("200", "Mow Lawn", "Mow the front and back yard"));
        assertNotNull(service.getTask("200"));
        assertEquals("Mow Lawn", service.getTask("200").getName());
    }

    @Test
    void testAddDuplicateId() {
        assertThrows(IllegalArgumentException.class,
            () -> service.addTask(new Task("100", "Mow Lawn", "Mow the front and back yard")));
    }

    @Test
    void testAddNullTask() {
        assertThrows(IllegalArgumentException.class, () -> service.addTask(null));
    }

    @Test
    void testDeleteTask() {
        service.deleteTask("100");
        assertNull(service.getTask("100"));
    }

    @Test
    void testDeleteMissingTask() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("999"));
    }

    @Test
    void testUpdateName() {
        service.updateName("100", "Mow Lawn");
        assertEquals("Mow Lawn", service.getTask("100").getName());
    }

    @Test
    void testUpdateDescription() {
        service.updateDescription("100", "Mow the front and back yard");
        assertEquals("Mow the front and back yard", service.getTask("100").getDescription());
    }

    @Test
    void testUpdateMissingTask() {
        assertThrows(IllegalArgumentException.class, () -> service.updateName("999", "Mow Lawn"));
        assertThrows(IllegalArgumentException.class,
            () -> service.updateDescription("999", "Mow the front and back yard"));
    }

    @Test
    void testUpdateWithBadValue() {
        assertThrows(IllegalArgumentException.class, () -> service.updateName("100", null));
        assertEquals("Wash Car", service.getTask("100").getName());
    }
}