package contact;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
        service.addContact(new Contact("100", "John", "Wick", "1234567890", "123 Main Street"));
    }

    @Test
    void testAddContact() {
        service.addContact(new Contact("200", "Jane", "Foster", "0987654321", "456 Apple Avenue"));
        assertNotNull(service.getContact("200"));
        assertEquals("Jane", service.getContact("200").getFirstName());
    }

    @Test
    void testAddDuplicateId() {
        assertThrows(IllegalArgumentException.class,
            () -> service.addContact(new Contact("100", "Jane", "Foster", "0987654321", "456 Apple Avenue")));
    }

    @Test
    void testAddNullContact() {
        assertThrows(IllegalArgumentException.class, () -> service.addContact(null));
    }

    @Test
    void testDeleteContact() {
        service.deleteContact("100");
        assertNull(service.getContact("100"));
    }

    @Test
    void testDeleteMissingContact() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("999"));
    }

    @Test
    void testUpdateFirstName() {
        service.updateFirstName("100", "Jane");
        assertEquals("Jane", service.getContact("100").getFirstName());
    }

    @Test
    void testUpdateLastName() {
        service.updateLastName("100", "Foster");
        assertEquals("Foster", service.getContact("100").getLastName());
    }

    @Test
    void testUpdatePhone() {
        service.updatePhone("100", "0987654321");
        assertEquals("0987654321", service.getContact("100").getPhone());
    }

    @Test
    void testUpdateAddress() {
        service.updateAddress("100", "456 Apple Avenue");
        assertEquals("456 Apple Avenue", service.getContact("100").getAddress());
    }

    @Test
    void testUpdateMissingContact() {
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("999", "Jane"));
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("999", "Foster"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("999", "0987654321"));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("999", "456 Apple Avenue"));
    }

    @Test
    void testUpdateWithBadValue() {
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("100", "123"));
        assertEquals("1234567890", service.getContact("100").getPhone());
    }
}