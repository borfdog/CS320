package contact;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    void testValidContact() {
        Contact c = new Contact("100", "John", "Wick", "1234567890", "123 Main Street");
        assertEquals("100", c.getContactId());
        assertEquals("John", c.getFirstName());
        assertEquals("Wick", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("123 Main Street", c.getAddress());
    }

    @Test
    void testIdNull() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact(null, "John", "Wick", "1234567890", "123 Main Street"));
    }

    @Test
    void testIdTooLong() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("12345678901", "John", "Wick", "1234567890", "123 Main Street"));
    }

    @Test
    void testFirstNameNull() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("100", null, "Wick", "1234567890", "123 Main Street"));
    }

    @Test
    void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("100", "ThisNameIsTooLong", "Wick", "1234567890", "123 Main Street"));
    }

    @Test
    void testLastNameNull() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("100", "John", null, "1234567890", "123 Main Street"));
    }

    @Test
    void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("100", "John", "ThisNameIsTooLong", "1234567890", "123 Main Street"));
    }

    @Test
    void testPhoneNull() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("100", "John", "Wick", null, "123 Main Street"));
    }

    @Test
    void testPhoneTooShort() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("100", "John", "Wick", "12345", "123 Main Street"));
    }

    @Test
    void testPhoneTooLong() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("100", "John", "Wick", "12345678901", "123 Main Street"));
    }

    @Test
    void testPhoneHasLetters() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("100", "John", "Wick", "12345abcde", "123 Main Street"));
    }

    @Test
    void testAddressNull() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("100", "John", "Wick", "1234567890", null));
    }

    @Test
    void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("100", "John", "Wick", "1234567890",
                "This address is way too long to be allowed"));
    }

    @Test
    void testSetters() {
        Contact c = new Contact("100", "John", "Wick", "1234567890", "123 Main Street");
        c.setFirstName("Jane");
        c.setLastName("Doe");
        c.setPhone("0987654321");
        c.setAddress("456 Apple Avenue");
        assertEquals("Jane", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("0987654321", c.getPhone());
        assertEquals("456 Apple Avenue", c.getAddress());
    }

    @Test
    void testSettersRejectBadValues() {
        Contact c = new Contact("100", "John", "Wick", "1234567890", "123 Main Street");
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setLastName("ThisNameIsTooLong"));
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("123"));
        assertThrows(IllegalArgumentException.class, () -> c.setAddress(null));
    }
}