package App;
import java.util.Date;

public class Appointment {
    private final String id;
    private Date date;
    private String description;

    public Appointment(String id, Date date, String description) {
        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException();
        }
        this.id = id;
        setDate(date);
        setDescription(description);
    }

    public String getId() { return id; }
    public Date getDate() { return date; }
    public String getDescription() { return description; }

    public void setDate(Date date) {
        if (date == null || date.before(new Date())) {
            throw new IllegalArgumentException();
        }
        this.date = date;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException();
        }
        this.description = description;
    }
}