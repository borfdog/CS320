package App;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
    Date future = new Date(System.currentTimeMillis() + 100000);

    @Test
    void addAppointment() {
        AppointmentService s = new AppointmentService();
        Appointment a = new Appointment("1", future, "x");
        s.add(a);
        assertSame(a, s.get("1"));
    }

    @Test
    void addDuplicate() {
        AppointmentService s = new AppointmentService();
        s.add(new Appointment("1", future, "x"));
        assertThrows(IllegalArgumentException.class, () -> s.add(new Appointment("1", future, "y")));
    }

    @Test
    void deleteAppointment() {
        AppointmentService s = new AppointmentService();
        s.add(new Appointment("1", future, "x"));
        s.delete("1");
        assertNull(s.get("1"));
    }

    @Test
    void deleteMissing() {
        AppointmentService s = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> s.delete("99"));
    }
}