package App;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import org.junit.jupiter.api.Test;

class AppointmentTest {
    Date future = new Date(System.currentTimeMillis() + 100000);
    Date past = new Date(System.currentTimeMillis() - 100000);

    @Test
    void validAppointment() {
        Appointment a = new Appointment("1", future, "visit");
        assertEquals("1", a.getId());
        assertEquals(future, a.getDate());
        assertEquals("visit", a.getDescription());
    }

    @Test
    void badId() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, future, "x"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", future, "x"));
    }

    @Test
    void badDate() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", null, "x"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", past, "x"));
    }

    @Test
    void badDescription() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", future, null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", future, "a".repeat(51)));
    }

    @Test
    void setters() {
        Appointment a = new Appointment("1", future, "x");
        Date newDate = new Date(System.currentTimeMillis() + 200000);
        a.setDate(newDate);
        a.setDescription("new");
        assertEquals(newDate, a.getDate());
        assertEquals("new", a.getDescription());
        assertThrows(IllegalArgumentException.class, () -> a.setDate(past));
        assertThrows(IllegalArgumentException.class, () -> a.setDescription(null));
    }
}