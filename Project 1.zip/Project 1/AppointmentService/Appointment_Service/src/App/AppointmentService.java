package App;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> list = new HashMap<>();

    public void add(Appointment a) {
        if (a == null || list.containsKey(a.getId())) {
            throw new IllegalArgumentException();
        }
        list.put(a.getId(), a);
    }

    public void delete(String id) {
        if (list.remove(id) == null) {
            throw new IllegalArgumentException();
        }
    }

    public Appointment get(String id) {
        return list.get(id);
    }
}